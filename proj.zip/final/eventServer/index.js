const port = 3000
const express = require('express')
const path = require('path')
const EventEmitter = require('events')
const randomNumberEmitter = new EventEmitter()
var app = express()
app.use(express.static(path.join(__dirname, 'static')))

const bodyParser = require('body-parser')
// parse application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({ extended: false }))

// parse application/json
app.use(bodyParser.json())

var config = {
  defaultEventRate: 1
}

const server = require('http').createServer(app)
const io = require('socket.io')(server)

//delay function to timeout if the timestamp from the client is not found in data
function delay(time) {
  return new Promise(resolve => setTimeout(resolve, time));
}

//looks for the timestamp recieved from the client in the data,
//if the timestamp is not found, it tries again.
//the resulting index (position) of the timestamp in the array is then
//returned as a promise and the server can then serve the client data
//up to the requested timestamp
async function lookForTimeStamp(timeStamp){
  var position = data.map(function(e) { return e.x; }).indexOf(timeStamp);
  while (position == -1){
    position = data.map(function(e) { return e.x; }).indexOf(timeStamp);
    //console.log(position);
    await delay(500);
  }
  return position;
}

io.on('connect', function (socket) {
  socket.on('post', function (d) {

    //d.interval is requested data interval
    //d.timeStamp is epoch timestamp at point of requested data
    //ensures returned data is before d.timeStamp (inclusive)
    //ensures returned data has interval or fewer datapoints (fewer in case server has been running for fewer than interval seconds)

    //this pormise ensures server sends data up to the requested timestamp
    position = lookForTimeStamp(d.timeStamp)

    //existence of position means the client's requested timestamp is now in
    //the dataset (last index)
    console.log(d.timeStamp)
    position.then(value => {
      let tempData = data.slice()
      if (d.interval >= tempData.length){
        //when there are fewer than d.interval dataPoints in data, send entire array
        socket.emit('data', tempData);
      } else {
        //when there are more than d.interval dataPoints in data, send the latest d.interval datapoints
        socket.emit('data', tempData.slice(-d.interval));
      }
    }).catch(err => {
      console.log(err);
    });
  })
})


//global array, holding up to 60 datapoints of generated data, generates one datapoint per second
var data = []
server.listen(port, function () {
  setInterval(function () {
    for (let i = 0; i < config.defaultEventRate; i++){
      d = {"x": Math.floor(Date.now()/1000),
        "y": [
          Math.floor(Math.random() * Math.floor(200)),
          Math.floor(Math.random() * Math.floor(200)),
          Math.floor(Math.random() * Math.floor(200)),
          Math.floor(Math.random() * Math.floor(200))
        ]
      }
      data.push(d)
    }
    if (data.length > 60) data.shift()
  }, 1000)


  console.log('server listetning on port', port)
})
